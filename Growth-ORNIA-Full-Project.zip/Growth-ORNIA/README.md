# Growth ORNIA
A responsive, buildless landing page. Serve `dist/` with any static host.

The reference portfolio has been adapted into a focused business acquisition page with native CSS and JavaScript, without a framework build step.

## Contact
The consultation form creates a mailto draft addressed to admin@orniagroup.com. It does not store submissions or connect to a CRM. Replace with the owner's approved HighLevel form or calendar embed when available.

## Media
User-supplied “My Movie 3.MOV”, 1280×720, 14.73 seconds. Converted to an audio-free, fast-start H.264 MP4 at its native resolution. Poster extracted from the supplied video. Fixed viewport background with muted autoplay, loop, a pause control, and dark monochrome/navy styling.

## Layout
Compact inset interface with centered serif hero, floating pill navigation, smaller buttons, and a continuous video canvas visible around the full page. Service sections and contact form remain inside the inset panel.

## Checks
JavaScript syntax checked with node --check. Desktop preview and process tab behavior inspected in browser. Replacement video playback verified at 1280×720. Responsive CSS includes 900px and 600px breakpoints; reduced-motion disables entrance effects and automatic video playback.

## Deployment
- Vercel: import this repository, use framework preset Other, leave the build command empty, and set output directory to `dist`.
- Netlify: publish directory `dist`; no build command.
- Other static hosting: upload the contents of `dist` to the web root.
- Local preview: `python3 -m http.server 8000 --directory dist`.

All video and poster assets are included. Google Fonts is the only externally loaded visual dependency; CSS includes fallback fonts. No package installation or build is required.
